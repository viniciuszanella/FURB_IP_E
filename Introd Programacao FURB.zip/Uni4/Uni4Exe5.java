package Uni4;

import java.util.Scanner;

public class Uni4Exe5 {
    Scanner scanner = new Scanner(System.in);
    boolean isAzul;

    public Uni4Exe5() {
        coletarDados();
        retornarDados();
    }
    
    private void coletarDados() {
        System.out.println("A cor é azul?");
        isAzul = scanner.nextBoolean();
    }

    private void retornarDados() {
        if (isAzul) {
            System.out.println("Sim");
        } else {
            System.out.println("Não");
        }
    }

    public static void main(String[] args) {
        new Uni4Exe5();
    }
}
