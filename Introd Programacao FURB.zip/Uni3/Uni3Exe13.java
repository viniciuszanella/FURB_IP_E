package Uni3;

import java.util.Scanner;

public class Uni3Exe13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Altura: ");
        double altura = scanner.nextDouble();

        System.out.print("Comprimento: ");
        double comprimento = scanner.nextDouble();

        double area = altura * comprimento;

        double quantidadeAzulejos = area * 9;

        double valorTotal = quantidadeAzulejos * 12.50;

        System.out.println("O valor final é R$" + String.format("%.2f", valorTotal));

        scanner.close();
    }
}

/**
 * | Altura (m) | Comprimento (m) | Valor Final Esperado |
 * |------------|------------------|----------------------|
 * | 2          | 6                | R$ 1350,00           |
 * | 1.8        | 2.6              | R$ 526,50            |
 * | 3          | 4                | R$ 1350,00           |
 */