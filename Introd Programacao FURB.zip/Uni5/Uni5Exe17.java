import java.util.Scanner;

public class Uni5Exe17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numeroInscricao;
        double altura;
        int inscricaoMaisAlto = 0;
        int inscricaoMaisBaixo = 0;
        double alturaMaisAlta = Double.MIN_VALUE;
        double alturaMaisBaixa = Double.MAX_VALUE;
        double somaAlturas = 0;
        int contador = 0;
        while (true) {
            System.out.print("Nº de inscrição: ");
            numeroInscricao = scanner.nextInt();
            if (numeroInscricao == 0)
                break;
            System.out.print("Altura: ");
            altura = scanner.nextDouble();
            if (altura > alturaMaisAlta) {
                alturaMaisAlta = altura;
                inscricaoMaisAlto = numeroInscricao;
            }
            if (altura < alturaMaisBaixa) {
                alturaMaisBaixa = altura;
                inscricaoMaisBaixo = numeroInscricao;
            }
            somaAlturas += altura;
            contador++;
        }
        if (contador > 0) {
            double media = somaAlturas / contador;
            System.out.println("O atleta mais baixo tem " + alturaMaisBaixa + "m e o seu número de inscrição é "
                    + inscricaoMaisBaixo);
            System.out.println("O atleta mais alto tem " + alturaMaisAlta + "m e o seu número de inscrição é "
                    + inscricaoMaisAlto);
            System.out.printf("A altura média do grupo de atletas é: %.2f\n", media);
        } else {
            System.out.println("Nenhum atleta foi cadastrado.");
        }
        scanner.close();
    }
}
