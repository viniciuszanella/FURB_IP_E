package Uni3;

import java.util.Scanner;

public class Uni3Exe16 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Valor total da compra: ");
        int valorCompra = scanner.nextInt();

        System.out.print("Valor total dado pelo cliente: ");
        int valorPago = scanner.nextInt();

        int troco = valorPago - valorCompra;

        int notas100 = troco / 100;
        troco %= 100;

        int notas10 = troco / 10;
        troco %= 10;

        int notas1 = troco;

        int totalNotas = notas100 + notas10 + notas1;

        System.out.println("O número mínimo de notas de troco é: " + totalNotas);
        System.out.println("Notas de 100: " + notas100);
        System.out.println("Notas de 10: " + notas10);
        System.out.println("Notas de 1: " + notas1);

        scanner.close();
    }
}

/**
 * | Valor Compra | Valor Pago | Troco | Notas de 100 | Notas de 10 | Notas de 1 | Total de Notas | Saída Esperada                                      |
 * |--------------|-------------|--------|---------------|--------------|-------------|------------------|----------------------------------------------------|
 * | 125          | 200         | 75     | 0             | 7            | 5           | 12               | Notas de 100: 0, Notas de 10: 7, Notas de 1: 5     |
 * | 378          | 500         | 122    | 1             | 2            | 2           | 5                | Notas de 100: 1, Notas de 10: 2, Notas de 1: 2     |
 * | 90           | 100         | 10     | 0             | 1            | 0           | 1                | Notas de 100: 0, Notas de 10: 1, Notas de 1: 0     |
 * | 999          | 1000        | 1      | 0             | 0            | 1           | 1                | Notas de 100: 0, Notas de 10: 0, Notas de 1: 1     |
 */