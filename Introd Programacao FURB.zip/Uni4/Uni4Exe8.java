package Uni4;

import java.util.Scanner;

public class Uni4Exe8 {
    Scanner scanner = new Scanner(System.in);
    char letra;

    public Uni4Exe8() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Entre com uma letra: ");
        letra = scanner.next().charAt(0);
    }

    private void logica() {
        letra = Character.toUpperCase(letra);
    }

    private void retornarDados() {
        if (letra == 'A' || letra == 'E' || letra == 'I' || letra == 'O' || letra == 'U') {
            System.out.println("É vogal");
        } else {
            System.out.println("NÃO é vogal");
            
        }
    }

    public static void main(String[] args) {
        new Uni4Exe8();
    }
}
