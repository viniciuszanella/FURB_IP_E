public class Uni5Exe11 {
    public static void main(String[] args) {
        long quebrados = 0;
        long quantidadeHora = 1;
        for (int hora = 1; hora <= 16; hora++) {
            System.out.printf("Hora %2d: %d biscoito(s) quebrado(s)%n", hora, quantidadeHora);
            quebrados += quantidadeHora;
            if (hora == 1) {
                quantidadeHora = 3;
            } else {
                quantidadeHora *= 3;
            }
        }
        System.out.println("\nTotal de biscoitos quebrados em 16 horas: " + quebrados);
    }
}
