package Uni4;

import java.util.Scanner;

public class Uni4Exe7 {
    Scanner scanner = new Scanner(System.in);
    double pesoCarta, valorSelo, valorPagar;

    public Uni4Exe7() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Entre com o peso da carta: ");
        pesoCarta = scanner.nextDouble();

        valorPagar = 0;
    }

    private void logica() {
        if (pesoCarta <= 50) {
            valorPagar = 0.45;
            return;
        }

        double pesoExcedente = pesoCarta - 50;
        double qtdAdicional = (pesoExcedente / 20) + 1;
        valorPagar = 0.45 + (0.45 * qtdAdicional);

        return;
    }

    private void retornarDados() {
        System.out.println(valorPagar);
    }

    public static void main(String[] args) {
        new Uni4Exe7();
    }
}
