import java.util.Scanner;

public class Uni5Exe34 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int opcao;
        int contasEncerradas = 0;
        do {
            System.out.println("\n--- MENU ---");
            System.out.println("(1) Encerrar conta de um hóspede");
            System.out.println("(2) Verificar número de contas encerradas");
            System.out.println("(3) Sair");
            System.out.print("Escolha uma opção: ");
            opcao = teclado.nextInt();
            teclado.nextLine();
            switch (opcao) {
                case 1:
                    System.out.print("Nome do hóspede: ");
                    String nome = teclado.nextLine();
                    System.out.print("Número de diárias: ");
                    int diarias = teclado.nextInt();
                    double taxaServico;
                    if (diarias < 15) {
                        taxaServico = 7.50;
                    } else if (diarias == 15) {
                        taxaServico = 6.50;
                    } else {
                        taxaServico = 5.00;
                    }
                    double total = diarias * (50.00 + taxaServico);
                    System.out.printf("Hóspede: %s - Total a pagar: R$ %.2f%n", nome, total);
                    contasEncerradas++;
                    break;
                case 2:
                    System.out.println("Contas encerradas até o momento: " + contasEncerradas);
                    break;
                case 3:
                    System.out.println("Encerrando o programa...");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
                    break;
            }
        } while (opcao != 3);
        teclado.close();
    }
}
