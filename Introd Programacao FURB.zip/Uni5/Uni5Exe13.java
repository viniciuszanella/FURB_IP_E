import java.util.Scanner;

public class Uni5Exe13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe o número total de reabastecimentos: ");
        int totalReabastecimentos = scanner.nextInt();
        double somaKmPorLitro = 0.0;
        for (int i = 1; i <= totalReabastecimentos; i++) {
            System.out.print("Parada " + i + " - Quilometragem percorrida desde a última parada (km): ");
            double quilometragem = scanner.nextDouble();
            System.out.print("Parada " + i + " - Combustível gasto (litros): ");
            double litros = scanner.nextDouble();
            double kmPorLitro = quilometragem / litros;
            somaKmPorLitro += kmPorLitro;
            System.out.printf("Parada %d: %.2f km por litro%n", i, kmPorLitro);
        }
        double mediaGeral = somaKmPorLitro / totalReabastecimentos;
        System.out.printf("%nQuilometragem média obtida por litro: %.2f km/l%n", mediaGeral);
        scanner.close();
    }
}
