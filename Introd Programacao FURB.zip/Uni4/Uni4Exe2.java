package Uni4;

import java.util.Scanner;

public class Uni4Exe2 {
    Scanner scanner = new Scanner(System.in);
    int valor;

    public Uni4Exe2() {
        coletarDados();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Entre com um valor inteiro maior do que 0: ");
        valor = scanner.nextInt();
    }

    private void retornarDados() {
        if ((valor % 2) == 0) {
            System.out.println("Número é par");
            return;
        }

        System.out.println("Número é impar");
        return;
    }

    public static void main(String[] args) {
        new Uni4Exe2();
    }
}
