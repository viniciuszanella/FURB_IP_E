package Uni4;

import java.util.Scanner;

public class Uni4Exe16 {
    Scanner scanner = new Scanner(System.in);
    int idadeHomem1, idadeHomem2, idadeMulher1, idadeMulher2, homemMaiorIdade, homemMenorIdade, mulherMaiorIdade, mulherMenorIdade, soma, produto;

    public Uni4Exe16() {
        lerDados();
        logica();
        retornarDados();
    }

    private void lerDados() {
        idadeHomem1 = scanner.nextInt();
        idadeHomem2 = scanner.nextInt();
        idadeMulher1 = scanner.nextInt();
        idadeMulher2 = scanner.nextInt();
    }

    private void logica() {
        if (idadeHomem1 > idadeHomem2) {
            homemMaiorIdade = idadeHomem1;
            homemMenorIdade = idadeHomem2;
        } else {
            homemMaiorIdade = idadeHomem2;
            homemMenorIdade = idadeHomem1;
        }

        if (idadeMulher1 > idadeMulher2) {
            mulherMaiorIdade = idadeMulher1;
            mulherMenorIdade = idadeMulher2;
        } else {
            mulherMaiorIdade = idadeMulher2;
            mulherMenorIdade = idadeMulher1;
        }

        soma = homemMaiorIdade + mulherMenorIdade;
        produto = homemMenorIdade * mulherMaiorIdade;
    }

    private void retornarDados() {
        System.out.println("Soma: " + soma + " Produto: " + produto);
    }

    public static void main(String[] args) {
        new Uni4Exe16();
    }
}
