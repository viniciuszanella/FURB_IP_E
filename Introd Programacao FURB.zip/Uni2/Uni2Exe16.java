package Uni2;
import java.util.Scanner;

public class Uni2Exe16 {

    /**
     * Leia quantidades de latas 350ml, garrafas 600ml, garrafas 2L. Calcule litros.
     * 
     * Teste de Mesa
     * Entrada: 10, 5, 2
     * Processamento: (10*0.35) + (5*0.6) + (2*2) = 3.5 + 3 + 4 = 10.5
     * Saida: 10.5 litros
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Latas (350ml): ");
        int latas = scanner.nextInt();

        System.out.print("Garrafas 600ml: ");
        int garrafas600 = scanner.nextInt();

        System.out.print("Garrafas 2L: ");
        int garrafas2L = scanner.nextInt();

        double totalLitros = (latas * 0.35) + (garrafas600 * 0.6) + (garrafas2L * 2);

        System.out.printf("Total em litros: %.2f\n", totalLitros);

        scanner.close();
    }
}