package Uni3;

import java.util.Scanner;

public class Uni3Exe12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nome: ");
        String nome = scanner.nextLine();

        System.out.print("Quantidade de horas trabalhadas no mês: ");
        int horasTrabalhadas = scanner.nextInt();

        System.out.print("Número de dependentes: ");
        int dependentes = scanner.nextInt();

        double salarioTrabalho = horasTrabalhadas * 10;  
        double salarioFamilia = dependentes * 60;        
        double salarioBruto = salarioTrabalho + salarioFamilia;

        double descontoINSS = salarioTrabalho * 0.085;
        double descontoIR = salarioTrabalho * 0.05;
        
        double salarioLiquido = salarioBruto - descontoINSS - descontoIR;

        System.out.println("O funcionário " + nome + " possui um salário bruto de R$" + String.format("%.2f", salarioBruto) + " e um salário líquido de R$" + String.format("%.2f", salarioLiquido));

        scanner.close();
    }
}

/**
 * | Nome   | Horas Trabalhadas | Dependentes | Salário Bruto | Salário Líquido |
 * |--------|-------------------|-------------|---------------|-----------------|
 * | João   | 160               | 2           | R$ 1720,00    | R$ 1504,00      |
 * | Carlos | 84                | 0           | R$ 840,00     | R$ 726,60       |
 */
