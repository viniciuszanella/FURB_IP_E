import java.util.Scanner;

public class Uni5Exe29 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe o valor a ser sacado: ");
        int valor = scanner.nextInt();
        if (valor <= 0) {
            System.out.println("Valor inválido. O saque deve ser maior que zero.");
        } else {
            int[] cedulas = { 20, 10, 5, 2, 1 };
            int[] qtdCedulas = new int[cedulas.length];
            int valorRestante = valor;
            for (int i = 0; i < cedulas.length; i++) {
                qtdCedulas[i] = valorRestante / cedulas[i];
                valorRestante %= cedulas[i];
            }
            System.out.println("\n--- Distribuição das cédulas ---");
            for (int i = 0; i < cedulas.length; i++) {
                if (qtdCedulas[i] > 0) {
                    System.out.println(qtdCedulas[i] + " cédula(s) de R$ " + cedulas[i]);
                }
            }
        }
        scanner.close();
    }
}
