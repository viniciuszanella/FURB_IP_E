import java.util.Scanner;

public class Uni5Exe5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int repeticoes = scanner.nextInt();
        int numero = 8;
        System.out.print(numero + " ");
        for (int i = 1; i <= repeticoes; i++) {
            System.out.print(numero + 2 + " ");
            numero = numero * 2;
            System.out.print(numero + " ");
        }
        scanner.close();
    }
}
