
package Uni4;

import java.util.Scanner;

public class Uni4Exe21 {
    Scanner scanner = new Scanner(System.in);
    double altura, massa;
    String classificacao;

    public Uni4Exe21() {
        coletarDados();
        logica();
        retornarDados();
    }
    
	private void coletarDados() {
        System.out.print("Altura (m): ");
		altura = scanner.nextDouble();

		System.out.print("Massa (kg): ");
		massa = scanner.nextDouble();
    }

    private void logica() {
        double imc = massa / (altura * altura);
		if (imc < 18.5) {
			classificacao = "Magreza";
		} else if (imc < 25.0) {
			classificacao = "Saudável";
		} else if (imc < 30.0) {
			classificacao = "Sobrepeso";
		} else if (imc < 35.0) {
			classificacao = "Obesidade Grau I";
		} else if (imc < 40.0) {
			classificacao = "Obesidade Grau II (severa)";
		} else {
			classificacao = "Obesidade Grau III (mórbida)";
		}
    }
    
    private void retornarDados() {
        System.out.println(classificacao);
    }

    public static void main(String[] args) {
        new Uni4Exe21();
	}
}
