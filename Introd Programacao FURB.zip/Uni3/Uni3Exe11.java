package Uni3;

import java.util.Scanner;

public class Uni3Exe11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a temperatura em °C: ");
        double celsius = scanner.nextDouble();

        double fahrenheit = (9.0 / 5.0) * celsius + 32;

        System.out.println(String.format("%.2f", fahrenheit));

        scanner.close();
    }
}

/**
 * | Temperatura em °C | Temperatura em °F Esperada |
 * |-------------------|----------------------------|
 * | 36                | 96.80                      |
 * | 2                 | 35.60                      |
 * | 0                 | 32.00                      |
 */