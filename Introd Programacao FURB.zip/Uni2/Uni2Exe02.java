package Uni2;
import java.util.Scanner;

public class Uni2Exe02 {

    /**
     * Leia 2 valores inteiros e imprima sua multiplicação.
     * 
     * Teste de Mesa
     * Entrada: 2, 2
     * Processamento: 2 * 2
     * Saida: 4
     * 
     * Entrada: 5, 1
     * Processamento: 5 * 1
     * Saida: 5
     * 
     * Entrada: 23, 0
     * Processamento: 23 * 0
     * Saida: 0
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Exercicio Uni2Exe02.");

        System.out.print("Insira o primeiro valor inteiro: ");
        int numero1 = scanner.nextInt();

        System.out.print("Insira o segundo valor inteiro: ");
        int numero2 = scanner.nextInt();

        int multiplicacao = numero1 * numero2;

        System.out.println("O resultado da multiplicação é: " + multiplicacao);

        scanner.close();
    }
}