import java.util.Scanner;

public class Uni5Exe12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Insira o numero de linhas: ");
        int linhas = scanner.nextInt();
        int numero = 0;
        for (int i = 1; i <= linhas; i++) {
            for (int j = 1; j <= i; j++) {
                numero++;
                System.out.print(numero + " ");
            }
            System.out.println();
        }
        scanner.close();
    }
}
