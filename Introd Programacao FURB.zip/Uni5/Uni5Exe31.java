import java.util.Scanner;

public class Uni5Exe31 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe um número inteiro positivo: ");
        int numero = scanner.nextInt();
        if (numero <= 0) {
            System.out.println("Número inválido. Deve ser positivo.");
            scanner.close();
            return;
        }
        System.out.println("\nnúmero\tdecomposição");
        int divisor = 2;
        int valorAtual = numero;
        while (valorAtual > 1) {
            if (valorAtual % divisor == 0) {
                System.out.println(valorAtual + "\t" + divisor);
                valorAtual /= divisor;
            } else {
                divisor++;
            }
        }
        System.out.println("1\t");
        scanner.close();
    }
}
