import java.util.Scanner;

public class Uni5Exe9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe o número de alunos: ");
        int n = scanner.nextInt();
        int acimaDe20 = 0;
        String nomesCom18 = "";
        for (int i = 1; i <= n; i++) {
            System.out.print("Nome do aluno " + i + ": ");
            String nome = scanner.next();
            System.out.print("Idade de " + nome + ": ");
            int idade = scanner.nextInt();
            if (idade == 18) {
                if (!nomesCom18.isEmpty()) {
                    nomesCom18 += ", ";
                }
                nomesCom18 += nome;
            }
            if (idade > 20) {
                acimaDe20++;
            }
        }
        System.out.println("\n--- Resultado ---");
        if (!nomesCom18.isEmpty()) {
            System.out.println("Nomes dos alunos que têm 18 anos: " + nomesCom18);
        } else {
            System.out.println("Nenhum aluno tem 18 anos.");
        }
        System.out.println("Quantidade de alunos com mais de 20 anos: " + acimaDe20);
        scanner.close();
    }
}
