package Uni2;
import java.util.Scanner;

public class Uni2Exe20 {

    /**
     * Leia número par de dobras em folha quadrada. Calcule quantos quadrados visíveis.
     * Fórmula: 4 ^ (d / 2)
     * 
     * Teste de Mesa
     * Entrada: 2
     * Processamento: 4^(2/2) = 4^1 = 4
     * Saida: 4
     * 
     * Entrada: 4
     * Processamento: 4^(4/2) = 4^2 = 16
     * Saida: 16
     * 
     * Entrada: 6
     * Processamento: 4^3 = 64
     * Saida: 64
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Número de dobras (par): ");
        int dobras = scanner.nextInt();

        int quadrados = (int) Math.pow(2, dobras / 2) * (int) Math.pow(2, dobras / 2);

        System.out.println("Quantidade de quadrados visíveis: " + quadrados);

        scanner.close();
    }
}