package Uni3;

import java.util.Scanner;

public class Uni3Exe09 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Raio: ");
        double raio = scanner.nextDouble();

        System.out.print("Altura: ");
        double altura = scanner.nextDouble();

        double volume = Math.PI * Math.pow(raio, 2) * altura;

        System.out.println("O volume da lata de óleo é: " + String.format("%.2f", volume));

        scanner.close();
    }
}

/**
 * | Raio (cm) | Altura (cm) | Volume Esperado (cm³) |
 * |-----------|-------------|-----------------------|
 * | 6         | 10          | 1130,97               |
 * | 12        | 12          | 5428,67               |
 * | 3         | 20          | 1696,46               |
 */