package Uni3;

import java.util.Scanner;

public class Uni3Exe14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Distância: ");
        double distancia = scanner.nextDouble();

        System.out.print("Tempo: ");
        double tempo = scanner.nextDouble();

        double velocidadeMedia = distancia / tempo;

        double combustivelGasto = distancia / 12;

        System.out.println("A velocidade média foi de " + String.format("%.2f", velocidadeMedia) + " km/h e a quantidade de combustível usado foi " + String.format("%.2f", combustivelGasto) + " litros.");

        scanner.close();
    }
}

/**
 * | Distância (km) | Tempo (h) | Velocidade Média Esperada (km/h) | Combustível Usado Esperado (litros) |
 * |-----------------|-----------|-----------------------------------|-------------------------------------|
 * | 240             | 4         | 60.00                             | 20.00                               |
 * | 150             | 2         | 75.00                             | 12.50                               |
 * | 120             | 3         | 40.00                             | 10.00                               |
 */