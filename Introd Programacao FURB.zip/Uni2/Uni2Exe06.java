package Uni2;
import java.util.Scanner;

public class Uni2Exe06 {

    /**
     * Leia o número de um funcionário, número de horas trabalhadas e valor por hora.
     * Calcule o salário com duas casas decimais.
     * 
     * Teste de Mesa
     * Entrada: 25, 100, 5.50
     * Processamento: 100 * 5.50 = 550.00
     * Saida: Número: 25, Salário: 550.00
     * 
     * Entrada: 1, 200, 20.50
     * Processamento: 200 * 20.50 = 4100.00
     * Saida: Número: 1, Salário: 4100.00
     * 
     * Entrada: 6, 145, 15.55
     * Processamento: 145 * 15.55 = 2254.75
     * Saida: Número: 6, Salário: 2254.75
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Número do funcionário: ");
        int numero = scanner.nextInt();

        System.out.print("Total de horas trabalhadas: ");
        double totalHorasTrabalhadas = scanner.nextDouble();

        System.out.print("Valor ganho por hora: ");
        double totalValorHora = scanner.nextDouble();

        double valorTotal = totalHorasTrabalhadas * totalValorHora;

        String resultado = String.format("%.2f", valorTotal);

        System.out.printf("O valor do funcionário " + numero + " é de " + resultado);
        scanner.close();
    }
}