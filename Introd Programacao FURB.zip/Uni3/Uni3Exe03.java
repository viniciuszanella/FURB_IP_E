package Uni3;

import java.util.Scanner;

public class Uni3Exe03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Preço do litro de gasolina: ");
        double precoLitro = scanner.nextDouble();

        System.out.print("Valor do pagamento: ");
        double valorPagamento = scanner.nextDouble();

        double litros = valorPagamento / precoLitro;

        System.out.println("O motorista conseguiu colocar: " + String.format("%.2f", litros) + " litros.");

        scanner.close();
    }
}

/**
 * | Preço do Litro | Pagamento | Litros Abastecidos |
 * |----------------|-----------|---------------------|
 * | 5.75           | 150       | 26.09               |
 * | 6.00           | 60        | 10.00               |
 * | 4.50           | 90        | 20.00               |
 */
