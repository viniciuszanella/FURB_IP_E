public class Uni5Exe21 {
    public static void main(String[] args) {
        double chico = 1.50;
        double ze = 1.10;
        int anos = 0;
        while (ze <= chico) {
            chico += 0.02;
            ze += 0.03;
            anos++;
        }
        System.out.println("Serão necessários " + anos + " anos para que Zé seja mais alto que Chico.");
        System.out.printf("Altura final de Chico: %.2f m\n", chico);
        System.out.printf("Altura final de Zé: %.2f m\n", ze);
    }
}
