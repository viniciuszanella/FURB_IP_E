package Uni3;

import java.util.Scanner;

public class Uni3Exe10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Cateto oposto: ");
        double catetoOposto = scanner.nextDouble();

        System.out.print("Cateto adjacente: ");
        double catetoAdjacente = scanner.nextDouble();

        double hipotenusa = Math.sqrt(Math.pow(catetoOposto, 2) + Math.pow(catetoAdjacente, 2));

        System.out.println("A hipotenusa é: " + String.format("%.2f", hipotenusa));

        scanner.close();
    }
}

/**
 * | Cateto Oposto | Cateto Adjacente | Hipotenusa Esperada |
 * |----------------|------------------|---------------------|
 * | 3              | 4                | 5.00                |
 * | 5              | 12               | 13.00               |
 * | 8              | 15               | 17.00               |
 */