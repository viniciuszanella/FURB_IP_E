package Uni4;

import java.util.Scanner;

public class Uni4Exe12 {
    Scanner scanner = new Scanner(System.in);
    float lado1, lado2, lado3;
    String tipo;

    public Uni4Exe12() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Entre com o comprimento do lado 1:");
        lado1 = scanner.nextFloat();
        System.out.println("Enre com o comprimento do lado 2:");
        lado2 = scanner.nextFloat();
        System.out.println("Entre com o comprimento do lado 3:");
        lado3 = scanner.nextFloat();
    }

    private void logica() {
        if (lado1 < (lado2 + lado3) && lado2 < (lado1 + lado3) && lado3 < (lado1 + lado2)) {
            if (lado1 == lado2 && lado1 == lado3) {
                tipo = "É equilátero";
                return;
            }

            if (lado1 == lado2 || lado2 == lado3 || lado1 == lado3) {
                tipo = "É isóceles.";
                return;            
            }

            tipo = "É escaleno";
            return;
        }

        tipo = "Não formam um triângulo";
        return;
    }

    private void retornarDados() {
        System.out.println(tipo);
    }

    public static void main(String[] args) {
        new Uni4Exe12();
    }
}
