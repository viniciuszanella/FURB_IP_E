package Uni4;

import java.util.Scanner;

public class Uni4Exe23 {
    Scanner scanner = new Scanner(System.in);
    int mesNumero;
    String mesExtenso;

    public Uni4Exe23() {
        coletarDados();
        logica();
        retornarDados(); 
    }

    private void coletarDados() {
        mesNumero = scanner.nextInt();
    }

    private void logica() {
        switch (mesNumero) {
            case 1:
            mesExtenso = "Janeiro";
            break;
            case 2:
            mesExtenso = "Fevereiro";
            break;
            case 3:
            mesExtenso = "Março";
            break;
            case 4:
            mesExtenso = "Abril";
            break;
            case 5:
            mesExtenso = "Maio";
            break;
            case 6:
            mesExtenso = "Junho";
            break;
            case 7:
            mesExtenso = "Julho";
            break;
            case 8:
            mesExtenso = "Agosto";
            break;
            case 9:
            mesExtenso = "Setembro";
            break;
            case 10:
            mesExtenso = "Outubro";
            break;
            case 11:
            mesExtenso = "Novembro";
            break;
            case 12:
            mesExtenso = "Dezembro";
            break;
            default:
            mesExtenso = "Valor Invalido";
            break;
        }
    }

    private void retornarDados() {
        System.out.println(mesExtenso);
    }

    public static void main(String[] args) {
        new Uni4Exe23();
    }
}
