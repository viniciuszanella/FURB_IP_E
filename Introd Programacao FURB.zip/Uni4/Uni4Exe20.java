package Uni4;

import java.util.Scanner;

public class Uni4Exe20 {
    Scanner scanner = new Scanner(System.in);
    double notaProva1, notaProva2, notaProva3, notaExercicios, media;
    char conceito;
    String status;

    public Uni4Exe20() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.print("Nota da Prova 1: ");
        notaProva1 = scanner.nextDouble();

        System.out.print("Nota da Prova 2: ");
        notaProva2 = scanner.nextDouble();

        System.out.print("Nota da Prova 3: ");
        notaProva3 = scanner.nextDouble();

        System.out.print("Média dos Exercícios: ");
        notaExercicios = scanner.nextDouble();
    }

    private void logica() {
        media = (notaProva1 + notaProva2 * 2 + notaProva3 * 3 + notaExercicios) / 7.0;
        if (media >= 9.0) {
            status = "Aprovado";
            conceito = 'A';
        } else if (media >= 7.5) {
            conceito = 'B';
            status = "Aprovado";
        } else if (media >= 6.0) {
            conceito = 'C';
            status = "Aprovado";
        } else if (media >= 4.0) {
            conceito = 'D';
            status = "Reprovado";
        } else {
            conceito = 'E';
            status = "Reprovado";
        }
    }

    private void retornarDados() {
        System.out.printf("A média de aproveitamento foi: %.2f. Conceito: %c. %s%n", media, conceito, status);
    }

    public static void main(String[] args) {
        new Uni4Exe20();
    }
}
