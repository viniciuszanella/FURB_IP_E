package Uni2;
import java.util.Scanner;

public class Uni2Exe03 {
    /**
     * Calcule a área da circunferência elevando o valor de raio ao quadrado e multiplicando por π (π = 3.14159).
     * 
     * Teste de Mesa
     * Entrada: 3
     * Processamento: (3 ^ 2) * 3.14159 = 9 * 3.14159
     * Saida: 28.27431
     * 
     * Entrada: 7
     * Processamento: (7 ^ 2) * 3.14159 = 49 * 3.14159
     * Saida: 153.93791
     * 
     * Entrada: 10
     * Processamento: (10 ^ 2) * 3.14159 = 100 * 3.14159
     * Saida: 314.159
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Insira o valor do raio de um circunferencia: ");
        double raio = scanner.nextDouble();

        double area = Math.pow(raio, 2) * 3.14159;

        System.out.println("A área da circunferencia é: " + area);

        scanner.close();
    }
}