import java.util.Scanner;

public class Uni5Exe20 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Massa inicial (em kg): ");
        double massaInicial = scanner.nextDouble();
        double massa = massaInicial;
        int tempo = 0;
        while (massa >= 0.0005) {
            massa /= 2;
            tempo += 50;
        }
        System.out.println("\n--- Resultado ---");
        System.out.printf("Massa inicial: %.6f kg\n", massaInicial);
        System.out.printf("Massa final: %.6f kg\n", massa);
        System.out.printf("Tempo necessário: %d segundos\n", tempo);
        scanner.close();
    }
}
