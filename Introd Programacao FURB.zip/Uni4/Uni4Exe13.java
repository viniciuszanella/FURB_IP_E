package Uni4;

import java.util.Scanner;

public class Uni4Exe13 {
    Scanner scanner = new Scanner(System.in);
    int carta1, carta2, carta3, qtdCartasBoas;
    String acao;

    public Uni4Exe13() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Informa as 3 cartas:");
        carta1 = scanner.nextInt();
        carta2 = scanner.nextInt();
        carta3 = scanner.nextInt();

        qtdCartasBoas = 0;
        acao = "-";
    }

    private void logica() {
        if (carta1 == 1 || carta1 == 2 || carta1 == 3) {
            qtdCartasBoas++;
        }
        if (carta2 == 1 || carta2 == 2 || carta2 == 3) {
            qtdCartasBoas++;
        }
        if (carta3 == 1 || carta3 == 2 || carta3 == 3) {
            qtdCartasBoas++;
        }

        if (qtdCartasBoas == 1) {
            acao = "TRUCO";
        }

        if (qtdCartasBoas == 2) {
            acao = "SEIS";
        }

        if (qtdCartasBoas == 3) {
            acao = "NOVE";
        }
    }

    private void retornarDados() {
        System.out.println(acao);
    }

    public static void main(String[] args) {
        new Uni4Exe13();
    }
}
