package Uni2;
import java.util.Scanner;

public class Uni2Exe08 {
    /**
     * Leia código, quantidade e valor unitário de duas peças. Calcule o valor total.
     * 
     * Teste de Mesa
     * Entrada: 12, 1, 5.30 | 16, 2, 5.10
     * Processamento: (1*5.30) + (2*5.10) = 5.30 + 10.20
     * Saida: 15.50
     * 
     * Entrada: 1, 2, 10.00 | 2, 1, 20.00
     * Processamento: 2*10 + 1*20 = 20 + 20
     * Saida: 40.00
     * 
     * Entrada: 1, 1, 100.00 | 2, 1, 0.00
     * Processamento: 100 + 0 = 100.00
     * Saida: 100.00
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Insira o código do primeiro produto: ");
        int produto1Cod = scanner.nextInt();

        System.out.print("Insira a quantidade do produto (" + produto1Cod + ") : ");
        int produto1Qtd = scanner.nextInt();

        System.out.print("Insira o valor do produto (" + produto1Cod + ") : ");
        double produto1Valor = scanner.nextDouble();

        System.out.print("Insira o código do segundo produto: ");
        int produto2Cod = scanner.nextInt();

        System.out.print("Insira a quantidade do segundo (" + produto2Cod + ") : ");
        int produto2Qtd = scanner.nextInt();

        System.out.print("Insira o valor do produto (" + produto2Cod + ") : ");
        double produto2Valor = scanner.nextDouble();

        double valorTotal = (produto1Valor * produto1Qtd) + (produto2Valor * produto2Qtd);

        System.out.print("O total a pagar pelas peças é de: " + valorTotal);

        scanner.close();
    }
}
