package Uni3;

import java.util.Scanner;

public class Uni3Exe06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o peso total do prato (em kg): ");
        double pesoTotal = scanner.nextDouble();

        double pesoPrato = 0.75;

        double pesoComida = pesoTotal - pesoPrato;

        double valor = pesoComida * 25.00;

        System.out.println("O valor do prato do cliente é R$" + String.format("%.2f", valor));

        scanner.close();
    }
}

/**
 * | Peso Total | Valor Esperado |
 * |------------|----------------|
 * | 2.42       | R$ 41.75       |
 * | 1.77       | R$ 25.50       |
 * | 1.00       | R$ 6.25        |
 */
