package Uni3;

import java.util.Scanner;

public class Uni3Exe15 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um número inteiro (até 3 dígitos): ");
        int numero = scanner.nextInt();

        int centenas = numero / 100;
        int dezenas = (numero % 100) / 10;
        int unidades = numero % 10;

        System.out.println(centenas + " centena(s) " + dezenas + " dezena(s) " + unidades + " unidade(s)");

        scanner.close();
    }
}

/**
 * | Número | Centenas | Dezenas | Unidades | Saída Esperada                    |
 * |--------|----------|---------|----------|----------------------------------|
 * | 326    | 3        | 2       | 6        | 3 centena(s) 2 dezena(s) 6 unidade(s) |
 * | 45     | 0        | 4       | 5        | 0 centena(s) 4 dezena(s) 5 unidade(s) |
 * | 7      | 0        | 0       | 7        | 0 centena(s) 0 dezena(s) 7 unidade(s) |
 * | 100    | 1        | 0       | 0        | 1 centena(s) 0 dezena(s) 0 unidade(s) |
 */