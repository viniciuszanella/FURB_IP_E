import java.util.Scanner;

public class Uni5Exe19 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double valorCompra;
        double totalRecebido = 0;
        while (true) {
            System.out.print("Valor da compra: ");
            valorCompra = scanner.nextDouble();
            if (valorCompra == 0)
                break;
            double valorPagar;
            if (valorCompra > 500) {
                valorPagar = valorCompra * 0.80; // 20% de desconto
            } else {
                valorPagar = valorCompra * 0.85; // 15% de desconto
            }
            System.out.printf("Valor a pagar: R$%.2f\n", valorPagar);
            totalRecebido += valorPagar;
        }
        System.out.printf("O valor total recebido foi de R$%.2f\n", totalRecebido);
        scanner.close();
    }
}
