
package Uni4;

import java.util.Scanner;

public class Uni4Exe18 {
    Scanner scanner = new Scanner(System.in);
    int diaVencimento, diaPagamento;
    double valorPrestacao, valorFinal;

    public Uni4Exe18() {
        coletarDados();

        retornarDados();
    }


	private void coletarDados() {
        System.out.print("Dia do vencimento: ");
		diaVencimento = scanner.nextInt();

		System.out.print("Dia do pagamento: ");
		diaPagamento = scanner.nextInt();

		System.out.print("Valor da prestação: ");
		valorPrestacao = scanner.nextDouble();
    }

    private void retornarDados() {
        valorFinal = valorPrestacao;
		if (diaPagamento <= diaVencimento) {
			valorFinal = valorPrestacao * 0.90;
			System.out.println("O pagamento está em dia. O valor da prestação = R$" + String.format("%.2f", valorFinal));
		} else if (diaPagamento <= diaVencimento + 5) {
			System.out.println("O pagamento está atrasado, mas sem multa. O valor da prestação = R$" + String.format("%.2f", valorFinal));
		} else {
			int diasAtraso = diaPagamento - diaVencimento;
			double multa = valorPrestacao * 0.02 * diasAtraso;
			valorFinal = valorPrestacao + multa;
			System.out.println("O pagamento está atrasado. Multa de 2% por dia de atraso. Valor da prestação = R$ " + String.format("%.2f", valorFinal));
		}
    }

    public static void main(String[] args) {
        new Uni4Exe18();
	}
}
