import java.util.Scanner;

public class Uni5Exe8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Insira o número de leituras:");
        int leituras = scanner.nextInt();
        double menorNegativo = 0;
        double mediaPositivo = 0;
        for (int i = 1; i <= leituras; i++) {
            System.out.println("Insira o número " + i + ":");
            double numero = scanner.nextDouble();
            if (i == 1) {
                menorNegativo = numero;
                mediaPositivo = numero;
            } else {
                if (numero < 0 && numero < menorNegativo) {
                    menorNegativo = numero;
                }
                if (numero > 0) {
                    mediaPositivo += numero;
                }
            }
            if (i == leituras) {
                System.out.printf("Menor número negativo: %.2f\n", menorNegativo);
                System.out.printf("Média dos números positivos: %.2f\n", mediaPositivo / leituras);
            }
        }
        scanner.close();
    }
}
