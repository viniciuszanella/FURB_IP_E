package Uni3;

import java.util.Scanner;

public class Uni3Exe07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Quantidade de 350ml: ");
        int quantidade350ml = scanner.nextInt();

        System.out.print("Quantidade de 600ml: ");
        int quantidade600ml = scanner.nextInt();

        System.out.print("Quantidade de 2L: ");
        int quantidade2l = scanner.nextInt();

        double litros350ml = quantidade350ml * 0.350;
        double litros600ml = quantidade600ml * 0.600;
        double litros2l = quantidade2l * 2.0;

        double totalLitros = litros350ml + litros600ml + litros2l;

        System.out.println("O cliente comprou ao total " + String.format("%.2f", totalLitros) + " litros.");

        scanner.close();
    }
}

/**
 * | Quantidade 350ml | Quantidade 600ml | Quantidade 2L | Total de Litros Esperado |
 * |------------------|------------------|----------------|--------------------------|
 * | 40               | 34               | 120            | 274.40                   |
 * | 10               | 5                | 20             | 45.00                    |
 * | 0                | 10               | 10             | 20.00                    |
 */
