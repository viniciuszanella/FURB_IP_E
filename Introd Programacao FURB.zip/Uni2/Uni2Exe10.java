package Uni2;
import java.util.Scanner;

public class Uni2Exe10 {
    /**
     * Leia tempo em segundos e converta para horas:minutos:segundos.
     * 
     * Teste de Mesa
     * Entrada: 3661
     * Processamento: 1h 1min 1s
     * Saida: 1:1:1
     * 
     * Entrada: 59
     * Processamento: 0h 0min 59s
     * Saida: 0:0:59
     * 
     * Entrada: 3600
     * Processamento: 1h 0min 0s
     * Saida: 1:0:0
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Insira o a duração do processo em segundos: ");
        int segundos = scanner.nextInt();

        int horas = segundos / 3600;

        int minutos = (segundos % 3600) / 60;

        segundos = minutos % 60;


        System.out.print(horas + ":" + minutos + ":" + segundos);

        scanner.close();
    }
}
