package Uni2;
import java.util.Scanner;

public class Uni2Exe15 {

    /**
     * Decomponha um valor monetário em notas e moedas.
     * 
     * Teste de Mesa
     * Entrada: 576.73
     * Processamento: Notas: 5x100, 1x50, 1x20, 0x10, 1x5, 0x2 | Moedas: 1x1, 1x0.5, 0x0.25, 2x0.10, 0x0.05, 3x0.01
     * Saida: Relação de notas e moedas
     * 
     * Entrada: 4.00
     * Processamento: 2x2.00
     * Saida: 2 notas de 2
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double valor = scanner.nextDouble();
        int centavos = (int) Math.round(valor * 100);

        System.out.println("NOTAS:");
        int[] notas = {10000, 5000, 2000, 1000, 500, 200};
        for (int nota : notas) {
            int qtd = centavos / nota;
            System.out.println(qtd + " nota(s) de R$ " + String.format("%.2f", nota / 100.0));
            centavos %= nota;
        }

        System.out.println("MOEDAS:");
        int[] moedas = {100, 50, 25, 10, 5, 1};
        for (int moeda : moedas) {
            int qtd = centavos / moeda;
            System.out.println(qtd + " moeda(s) de R$ " + String.format("%.2f", moeda / 100.0));
            centavos %= moeda;
        }

        scanner.close();
    }
}