package Uni3;

import java.util.Scanner;

public class Uni3Exe08 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Valor em dólares recebido pelo cliente: ");
        double valorDolares = scanner.nextDouble();

        System.out.print("Cotação do dólar hoje: ");
        double cotacaoDolar = scanner.nextDouble();

        double valorEmReais = valorDolares * cotacaoDolar;

        System.out.println("O atendente deve devolver R$" + String.format("%.2f", valorEmReais) + " para o cliente.");

        scanner.close();
    }
}

/**
 * | Valor em Dólares | Cotação do Dólar | Valor Devolvido |
 * |-------------------|-------------------|-----------------|
 * | 440               | 5.65              | R$ 2486,00      |
 * | 100               | 5.00              | R$ 500,00       |
 * | 50                | 4.20              | R$ 210,00       |
 */