import java.util.Scanner;

public class Uni5Exe27 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int diaMaiorProducao = 0;
        int maiorProducao = 0;
        int totalManha = 0;
        int totalTarde = 0;
        while (true) {
            int dia;
            do {
                System.out.print("Dia do mês de abril (1 a 30): ");
                dia = scanner.nextInt();

                if (dia < 1 || dia > 30) {
                    System.out.println("Dia inválido");
                }
            } while (dia < 1 || dia > 30);
            System.out.print("Peças produzidas no turno da manhã: ");
            int manha = scanner.nextInt();
            System.out.print("Peças produzidas no turno da tarde: ");
            int tarde = scanner.nextInt();
            double valorReceber = 0;
            int producaoTotal = manha + tarde;
            if (dia >= 1 && dia <= 15) {
                if (producaoTotal > 100 && manha >= 30 && tarde >= 30) {
                    valorReceber = producaoTotal * 0.80;
                } else {
                    valorReceber = producaoTotal * 0.50;
                }
            } else {
                valorReceber = manha * 0.40 + tarde * 0.30;
            }
            System.out.printf("R$ %.2f (valor recebido)\n", valorReceber);
            if (producaoTotal > maiorProducao) {
                maiorProducao = producaoTotal;
                diaMaiorProducao = dia;
            }
            totalManha += manha;
            totalTarde += tarde;
            System.out.print("Novo funcionário (1.sim 2.não)? ");
            int opcao = scanner.nextInt();
            if (opcao == 2)
                break;
        }
        System.out.println("\n--- RELATÓRIO FINAL ---");
        System.out.println("Dia de maior produção: " + diaMaiorProducao);
        if (totalManha > totalTarde) {
            System.out.println("Turno com maior produção: manhã (" + totalManha + " peças)");
        } else {
            System.out.println("Turno com maior produção: tarde (" + totalTarde + " peças)");
        }
        scanner.close();
    }
}
