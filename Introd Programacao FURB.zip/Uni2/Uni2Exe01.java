package Uni2;
import java.util.Scanner;

public class Uni2Exe01 {
    /**
     * Leia 2 valores inteiros e imprima sua soma.
     * 
     * Teste de Mesa
     * Entrada: 10, 20
     * Processamento: 10 + 20
     * Saida: 30
     * 
     * Entrada: -5, 15
     * Processamento: -5 + 15
     * Saida: 10
     * 
     * Entrada: 0, 0
     * Processamento: 0 + 0
     * Saida: 0
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Exercicio Uni2Exe01.");

        System.out.print("Insira o primeiro valor inteiro: ");
        int numero1 = scanner.nextInt();

        System.out.print("Insira o segundo valor inteiro: ");
        int numero2 = scanner.nextInt();

        int soma = numero1 + numero2;

        System.out.println("O resultado da soma é: " + soma);

        scanner.close();
    }
}