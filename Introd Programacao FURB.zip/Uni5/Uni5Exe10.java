public class Uni5Exe10 {
    public static void main(String[] args) {
        int soma = 0;
        int potencia = 0;
        int contador = 0;
        String strx, stry = "";
        for (int x = 0; x <= 10000; x++) {
            for (int y = 0; y <= 10000; y++) {
                soma = x + y;
                potencia = (int) Math.pow(soma, 2);
                strx = x + "" + y;
                stry = potencia + "";
                if (strx.equals(stry)) {
                    contador++;
                    System.out.printf("[%d] %d + %d = %d -> %d%n", contador, x, y, soma, potencia);
                }
                if (contador >= 10)
                    break;
            }
            if (contador >= 10)
                break;
        }
    }
}
