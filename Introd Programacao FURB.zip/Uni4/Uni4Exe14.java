package Uni4;

import java.util.Scanner;

public class Uni4Exe14 {
    Scanner scanner = new Scanner(System.in);
    int dia, mes, ano;
    String statusData;

    public Uni4Exe14() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Digite o dia: ");
        dia = scanner.nextInt();
        System.out.println("Digite o mês: ");
        mes = scanner.nextInt();
        System.out.println("Digite o ano: ");
        ano = scanner.nextInt();
    }

    private void logica() {
        if (dia > 0 && dia < 32 && mes > 0 && mes < 13 && ano > 0) {
            if (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) {
                statusData = "Data válida";
                return;
            }          
            
            if (mes != 2 && dia < 31) {
                statusData = "Data válida";
                return;
            }

            if (mes == 2 && dia < 29) {
                statusData = "Data válida";
                return;
            }

            if (dia == 29 && ano % 4 == 0 && !(ano % 100 == 0) && ano % 400 != 0) {
                statusData = "Data válida";
                return;
            }
            
        }

        statusData = "Data inválida";
        return;
    }

    private void retornarDados() {
        System.out.println(statusData);
    }

    public static void main(String[] args) {
        new Uni4Exe14();
    }
}
