import java.util.Scanner;

public class Uni5Exe7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int leituras;
        double maiorNumero = 0;
        double menorNumero = 0;
        System.out.println("Insira o número de leituras:");
        leituras = scanner.nextInt();
        for (int i = 1; i <= leituras; i++) {
            System.out.println("Insira o número " + i + ":");
            double numero = scanner.nextDouble();
            if (i == 1) {
                maiorNumero = numero;
                menorNumero = numero;
            } else {
                if (numero > maiorNumero) {
                    maiorNumero = numero;
                }
                if (numero < menorNumero) {
                    menorNumero = numero;
                }
            }
            if (i == leituras) {
                System.out.printf("Maior número: %.2f\n", maiorNumero);
                System.out.printf("Menor número: %.2f\n", menorNumero);
            }
        }
        scanner.close();
    }
}
