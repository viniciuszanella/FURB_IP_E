package Uni3;

import java.util.Scanner;

public class Uni3Exe02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o preço do par de sapatos: ");
        double preco = scanner.nextDouble();

        double desconto = preco * 0.12;
        double precoComDesconto = preco - desconto;

        System.out.println("O valor do desconto é de R$" + String.format("%.2f", desconto));
        System.out.println("O preço do par de sapatos com desconto é R$" + String.format("%.2f", precoComDesconto));

        scanner.close();
    }
}

/**
 * | Preço | Desconto | Preço com desconto |
 * | ----- | -------- | ------------------ |
 * | 100   | 12.00    | 88.00              |
 * | 129   | 15.48    | 113.52             |
 * | 200   | 24.00    | 176.00             |
 */