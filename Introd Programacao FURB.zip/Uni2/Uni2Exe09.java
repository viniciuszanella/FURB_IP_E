package Uni2;
import java.util.Scanner;

public class Uni2Exe09 {

    /**
     * Leia valor em dólares e cotação. Converta para reais.
     * 
     * Teste de Mesa
     * Entrada: 100, 5.50
     * Processamento: 100 * 5.50 = 550.00
     * Saida: 550.00
     * 
     * Entrada: 50, 4.80
     * Processamento: 50 * 4.80 = 240.00
     * Saida: 240.00
     * 
     * Entrada: 0, 6.00
     * Processamento: 0 * 6.00 = 0.00
     * Saida: 0.00
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Quantos dollars (US$) você deseja trocar? ");
        double dollar = scanner.nextDouble();

        double reais = dollar * 5.41;

        System.out.print("Você recebeu R$ " + reais);

        scanner.close();
    }
}