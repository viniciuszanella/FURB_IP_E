import java.util.Scanner;

public class Uni5Exe30 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe o valor inicial N: ");
        int N = scanner.nextInt();
        System.out.print("Informe o decremento K: ");
        int K = scanner.nextInt();
        System.out.print("Informe o tamanho da mochila M: ");
        int M = scanner.nextInt();
        System.out.println("\n--- Elementos da sequência ---");
        int valorAtual = N;
        int somaDentro = 0;
        int somaFora = 0;
        System.out.println("Entraram na mochila:");
        while (valorAtual > 0) {
            System.out.print(valorAtual + " ");
            if (somaDentro + valorAtual <= M) {
                somaDentro += valorAtual;
            } else {
                somaFora += valorAtual;
            }
            valorAtual -= K;
        }
        System.out.println("\n\nSoma dos que entraram: " + somaDentro);
        System.out.println("Soma dos que ficaram fora: " + somaFora);
        scanner.close();
    }
}
