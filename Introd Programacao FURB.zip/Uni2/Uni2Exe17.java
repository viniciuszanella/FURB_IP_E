package Uni2;
import java.util.Scanner;

public class Uni2Exe17 {

    /**
     * Calcule salário com base em horas e dependentes. Descontos INSS (8.5%) e IR (5%).
     * 
     * Teste de Mesa
     * Entrada: João, 160, 2
     * Salário trabalho: 160*10 = 1600
     * Salário família: 2*60 = 120
     * INSS: 136
     * IR: 80
     * Líquido: 1600 + 120 - 136 - 80 = 1504
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nome do funcionário: ");
        String nome = scanner.nextLine();

        System.out.print("Horas trabalhadas: ");
        int horas = scanner.nextInt();

        System.out.print("Número de dependentes: ");
        int dependentes = scanner.nextInt();

        double salarioTrabalho = horas * 10;
        double salarioFamilia = dependentes * 60;

        double descontoINSS = salarioTrabalho * 0.085;
        double descontoIR = salarioTrabalho * 0.05;

        double salarioLiquido = salarioTrabalho + salarioFamilia - descontoINSS - descontoIR;

        System.out.println("Nome: " + nome);
        System.out.printf("Salário bruto: R$ %.2f\n", salarioTrabalho + salarioFamilia);
        System.out.printf("Salário líquido: R$ %.2f\n", salarioLiquido);

        scanner.close();
    }
}