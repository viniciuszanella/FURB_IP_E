package Uni4;

import java.util.Scanner;

public class Uni4Exe3 {
    Scanner scanner = new Scanner(System.in);
    double valor1, valor2, valorMaior, valorMenor;

    public Uni4Exe3() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Entre com o primeiro valor: ");
        valor1 = scanner.nextDouble();

        
        System.out.println("Entre com o segundo valor: ");
        valor2 = scanner.nextDouble();
    }

    private void logica() {
        if (valor1 > valor2) {
            valorMaior = valor1;
            valorMenor = valor2;
            return;
        }

        valorMaior = valor2;
        valorMenor = valor1;
        return;
    }

    private void retornarDados() {
        System.out.println("O valor " + valorMaior + " é maior do que o valor " + valorMenor);
    }

    public static void main(String[] args) {
        new Uni4Exe3(); 
    }
}
