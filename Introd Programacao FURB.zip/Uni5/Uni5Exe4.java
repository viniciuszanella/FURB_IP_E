public class Uni5Exe4 {
    public static void main(String[] args) {
        int soma = 0;
        for (int i = 1; i <= 20; i++) {
        }
        System.out.println("Soma da série: " + soma);
    }
}
