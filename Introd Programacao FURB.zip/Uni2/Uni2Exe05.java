package Uni2;
import java.util.Scanner;

public class Uni2Exe05 {
    /**
     * Leia quatro valores inteiros A, B, C e D e calcule: DIFERENCA = (A * B - C * D).
     * 
     * Teste de Mesa
     * Entrada: 5, 6, 7, 8
     * Processamento: (5 * 6) - (7 * 8) = 30 - 56
     * Saida: -26
     * 
     * Entrada: 0, 10, 2, 3
     * Processamento: (0 * 10) - (2 * 3) = 0 - 6
     * Saida: -6
     * 
     * Entrada: 9, 9, 9, 9
     * Processamento: (9 * 9) - (9 * 9) = 81 - 81
     * Saida: 0
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Insira a primeira nota: ");
        double nota1 = scanner.nextDouble();

        System.out.print("Insira a segunda nota: ");
        double nota2 = scanner.nextDouble();

        double media = ((nota1 * 3.5) + (nota2 * 7.5)) / 11;
        System.out.print("Sua média é: " + media);
        scanner.close();
    }
}