import java.util.Scanner;

public class Uni5Exe15 {
    public static void main(String[] args) {
        Scanner Scanner = new Scanner(System.in);
        String nome = "";
        double nota1, nota2, media;
        do {
            System.out.println("Digite o nome do aluno ou 'sair' para receber as médias:");
            nome = Scanner.nextLine().toLowerCase();
            if (nome.equals("sair"))
                break;
            System.out.println("Digite a primeira nota de " + nome + ":");
            nota1 = Scanner.nextDouble();
            System.out.println("Digite a segunda nota de " + nome + ":");
            nota2 = Scanner.nextDouble();
            media = (nota1 + nota2) / 2;
            System.out.printf("A média de %s é: %.2f\n", nome, media);
            Scanner.nextLine();
        } while (!nome.equals("sair"));
        Scanner.close();
    }
}
