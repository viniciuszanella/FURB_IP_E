import java.util.Scanner;

public class Uni5Exe16 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double alturaM = 0, alturaF = 0, alturaO = 0;
        int countM = 0, countF = 0, countO = 0;
        double altura = 1;
        while (altura != 0) {
            System.out.print("Digite a altura (0 para sair): ");
            altura = scanner.nextDouble();
            if (altura != 0) {
                System.out.print("Digite a altura: ");
                altura = scanner.nextDouble();
                System.out.print("Digite o sexo (M/F ou O): ");
                char sexo = scanner.next().toUpperCase().charAt(0);
                if (sexo == 'M') {
                    alturaM += altura;
                    countM++;
                } else if (sexo == 'F') {
                    alturaF += altura;
                    countF++;
                } else if (sexo == 'O') {
                    alturaO += altura;
                    countO++;
                }
            }
        }
        System.out.println("A média da altura das mulheres é:" + (alturaM / countF));
        System.out.println(
                "A média da altura das mulheres é:" + ((alturaM + alturaF + alturaO) / (countM + countF + countO)));
        scanner.close();
    }
}
