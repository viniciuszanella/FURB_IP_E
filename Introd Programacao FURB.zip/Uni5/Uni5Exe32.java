import java.util.Scanner;

public class Uni5Exe32 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe o dia da semana do 1º dia do mês (1=Dom, 2=Seg, ..., 7=Sáb): ");
        int primeiroDia = scanner.nextInt();
        System.out.print("Informe o número de dias do mês: ");
        int numDias = scanner.nextInt();
        System.out.println();
        System.out.println("D\tS\tT\tQ\tQ\tS\tS");
        int i = 1;
        while (i < primeiroDia) {
            System.out.print("\t");
            i++;
        }
        int dia = 1;
        while (dia <= numDias) {
            System.out.print(dia + "\t");
            if ((dia + primeiroDia - 1) % 7 == 0)
                System.out.println();
            dia++;
        }
        System.out.println();
        scanner.close();
    }
}
