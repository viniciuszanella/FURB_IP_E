import java.util.Scanner;

public class Uni5Exe28 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int votosNenhum = 0;
        int votosCPM22 = 0;
        int votosSkank = 0;
        int votosJotaQuest = 0;
        int totalVotos = 0;
        while (true) {
            System.out.println("\nEscolha o conjunto e digite o código correspondente:");
            System.out.println("1 - Nenhum de Nós");
            System.out.println("2 - CPM22");
            System.out.println("3 - Skank");
            System.out.println("4 - Jota Quest");
            System.out.print("Código do voto: ");
            int codigo = scanner.nextInt();
            switch (codigo) {
                case 1:
                    votosNenhum++;
                    break;
                case 2:
                    votosCPM22++;
                    break;
                case 3:
                    votosSkank++;
                    break;
                case 4:
                    votosJotaQuest++;
                    break;
                default:
                    System.out.println("Código inválido! Voto não computado.");
                    continue;
            }
            totalVotos++;
            System.out.print("Mais um voto: s (SIM) / n (NÃO)? ");
            char continuar = scanner.next().toLowerCase().charAt(0);
            if (continuar == 'n') {
                break;
            }
        }
        System.out.println("\n--- RESULTADO FINAL ---");
        if (totalVotos == 0) {
            System.out.println("Nenhum voto registrado.");
            scanner.close();
            return;
        }
        double percNenhum = (votosNenhum * 100.0) / totalVotos;
        double percCPM22 = (votosCPM22 * 100.0) / totalVotos;
        double percSkank = (votosSkank * 100.0) / totalVotos;
        double percJotaQuest = (votosJotaQuest * 100.0) / totalVotos;
        System.out.printf("Nenhum de Nós: %d votos (%.1f%%)\n", votosNenhum, percNenhum);
        System.out.printf("CPM22: %d votos (%.1f%%)\n", votosCPM22, percCPM22);
        System.out.printf("Skank: %d votos (%.1f%%)\n", votosSkank, percSkank);
        System.out.printf("Jota Quest: %d votos (%.1f%%)\n", votosJotaQuest, percJotaQuest);
        String vencedor = "Nenhum de Nós";
        int maiorVotos = votosNenhum;
        if (votosCPM22 > maiorVotos) {
            vencedor = "CPM22";
            maiorVotos = votosCPM22;
        }
        if (votosSkank > maiorVotos) {
            vencedor = "Skank";
            maiorVotos = votosSkank;
        }
        if (votosJotaQuest > maiorVotos) {
            vencedor = "Jota Quest";
            maiorVotos = votosJotaQuest;
        }
        System.out.println("\nO grupo vencedor é: " + vencedor + " com " + maiorVotos + " votos!");
        scanner.close();
    }
}
