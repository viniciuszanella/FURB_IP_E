package Uni2;
import java.util.Scanner;

public class Uni2Exe14 {
    /**
     * Decomponha um valor inteiro em notas: 100, 50, 20, 10, 5, 2, 1.
     * 
     * Teste de Mesa
     * Entrada: 576
     * Processamento: 5x100, 1x50, 1x20, 0x10, 1x5, 0x2, 1x1
     * Saida: 5 notas de 100, 1 de 50, 1 de 20, 1 de 5, 1 de 1
     * 
     * Entrada: 11257
     * Processamento: 112x100, 1x50, 0x5, 1x2
     * Saida: ...
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int valor = scanner.nextInt();
        int restante = valor;

        System.out.println(valor);

        int[] notas = {100, 50, 20, 10, 5, 2, 1};

        for (int nota : notas) {
            int qtd = restante / nota;
            System.out.println(qtd + " nota(s) de R$ " + nota + ",00");
            restante %= nota;
        }

        scanner.close();
    }
}