package Uni4;

import java.util.Scanner;

public class Uni4Exe15 {
    Scanner scanner = new Scanner(System.in);
    int meses, ajuste;

    public Uni4Exe15() {
        coletarDados();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Digite a quantidade de meses trabalhados: ");
        meses = scanner.nextInt();
    }

    private void retornarDados() {
        if(meses <= 12) {
            System.out.println("O funcionário irá receber 5% de reajuste.");
            return;
        }

        if (meses >= 13 && meses <= 48) {
            System.out.println("O funcionário irá receber 7% de reajuste.");
            return;
        }

        System.out.println("Reajuste não informado");
        return;
    }

    public static void main(String[] args) {
        new Uni4Exe15();
    }
}
