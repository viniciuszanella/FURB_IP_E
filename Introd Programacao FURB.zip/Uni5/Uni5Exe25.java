import java.util.Scanner;

public class Uni5Exe25 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int pontosDireita = 0;
        int pontosEsquerda = 0;
        char ponto;
        System.out.println("Digite o resultado dos pontos (D para direita, E para esquerda).");
        System.out.println("A partida termina automaticamente conforme as regras.\n");
        while (true) {
            System.out.print("Ponto (D/E): ");
            ponto = scanner.next().toUpperCase().charAt(0);
            if (ponto != 'D' && ponto != 'E') {
                System.out.println("Entrada inválida! Digite apenas D ou E.");
                continue;
            }
            if (ponto == 'D') {
                pontosDireita++;
            } else {
                pontosEsquerda++;
            }
            System.out.printf("Placar: Esquerda %d x %d Direita%n", pontosEsquerda, pontosDireita);
            if (verificaVitoria(pontosEsquerda, pontosDireita))
                break;
        }
        if (pontosDireita > pontosEsquerda) {
            System.out.printf("\n Jogador da DIREITA venceu por %d x %d!\n", pontosDireita, pontosEsquerda);
        } else {
            System.out.printf("\n Jogador da ESQUERDA venceu por %d x %d!\n", pontosEsquerda, pontosDireita);
        }
        scanner.close();
    }

    private static boolean verificaVitoria(int esquerda, int direita) {
        int diferenca = Math.abs(esquerda - direita);
        if ((esquerda >= 21 || direita >= 21) && diferenca >= 2) {
            return true;
        }
        return false;
    }
}
