package Uni4;

import java.util.Scanner;

public class Uni4Exe4 {
    Scanner scanner = new Scanner(System.in);
    float numero;

    public Uni4Exe4() {
        coletarDados();
        retornarDados();
    }
    
    private void coletarDados() {
        System.out.println("Enre com um número maior que 0:");
        numero = scanner.nextFloat();
    }

    private void retornarDados() {
        if (numero % 1 == 0) {
            System.out.println("Casas decimais não foram digitadas.");
        } else {
            System.out.println("Casas decimais foram digitadas.");  
        }
    }

    public static void main(String[] args) {
        new Uni4Exe4();
    }
}
