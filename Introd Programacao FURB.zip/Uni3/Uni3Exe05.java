package Uni3;

import java.util.Scanner;

public class Uni3Exe05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a quantidade de frangos: ");
        int quantidade = scanner.nextInt();

        double custoPorFrango = 4.00 + (2 * 3.50);
        double gastoTotal = quantidade * custoPorFrango;

        System.out.println("O gasto total para marcar " + quantidade + " é R$" + String.format("%.2f", gastoTotal));

        scanner.close();
    }
}

/**
 * | Frangos | Gasto Esperado |
 * |---------|----------------|
 * | 625     | 6875.00        |
 * | 84      | 924.00         |
 * | 100     | 1100.00        |
 */
