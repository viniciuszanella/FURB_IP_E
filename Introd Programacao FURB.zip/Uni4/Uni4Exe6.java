package Uni4;

import java.util.Scanner;

public class Uni4Exe6 {
    Scanner scanner = new Scanner(System.in);
    char caractere;

    public Uni4Exe6() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Insira um caractere: ");
        caractere = scanner.next().charAt(0);
    }

    private void logica() {
        caractere = Character.toUpperCase(caractere);
    }

    private void retornarDados() {
        switch (caractere) {
            case 'M':
                System.out.println("Masculino");
                break;
            case 'F':
                System.out.println("Feminino");
                break;
            case 'I':
                System.out.println("Não informado");
                break;
    
            default:
                System.out.println("Entrada Incorreta");
                break;
        }
    }

    public static void main(String[] args) {
        new Uni4Exe6();
    }
}
