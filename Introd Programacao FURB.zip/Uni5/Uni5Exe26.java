import java.util.Scanner;

public class Uni5Exe26 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Valor máximo de pedágio (R$): ");
        double valorMaximo = scanner.nextDouble();
        int totalTrechos = 0;
        int trechosAcimaDoLimite = 0;
        int trechosAceitosAcima150Km = 0;
        while (true) {
            System.out.print("Valor do pedágio (R$): ");
            double pedagio = scanner.nextDouble();
            if (pedagio < 0)
                break;
            System.out.print("Distância do trecho (Km): ");
            double distancia = scanner.nextDouble();
            totalTrechos++;
            if (pedagio > valorMaximo) {
                trechosAcimaDoLimite++;
            } else {
                if (distancia > 150)
                    trechosAceitosAcima150Km++;
            }
        }
        System.out.println("\n--- RELATÓRIO FINAL ---");
        System.out.println(trechosAcimaDoLimite + " trechos com valor acima do qual ele nega-se a pagar.");
        System.out.println(totalTrechos + " trechos informados.");
        System.out.println(trechosAceitosAcima150Km + " trechos acima de 150km com valor aceito por ele.");
        scanner.close();
    }
}
