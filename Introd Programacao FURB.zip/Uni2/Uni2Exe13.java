package Uni2;
import java.util.Scanner;

public class Uni2Exe13 {

    /**
     * Carro Y se distancia 1 km a cada 2 min de X. Leia a distância.
     * 
     * Teste de Mesa
     * Entrada: 30
     * Processamento: 30 * 2 = 60
     * Saida: 60 minutos
     * 
     * Entrada: 60
     * Processamento: 60 * 2 = 120
     * Saida: 120 minutos
     * 
     * Entrada: 0
     * Processamento: 0 * 2 = 0
     * Saida: 0 minutos
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Distância (km): ");
        int distancia = scanner.nextInt();

        int tempo = distancia * 2;

        System.out.println("Tempo (minutos): " + tempo);

        scanner.close();
    }
}