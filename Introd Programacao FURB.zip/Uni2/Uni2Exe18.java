package Uni2;
import java.util.Scanner;

public class Uni2Exe18 {

    /**
     * Leia comprimento e altura da parede. 1m² = 9 azulejos. 1 azulejo = R$12.50.
     * 
     * Teste de Mesa
     * Entrada: 2, 2
     * Área: 4m² → 36 azulejos → 36*12.50 = 450.00
     * Saida: 450.00
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Comprimento da parede (m): ");
        double comprimento = scanner.nextDouble();

        System.out.print("Altura da parede (m): ");
        double altura = scanner.nextDouble();

        double area = comprimento * altura;
        int totalAzulejos = (int) Math.ceil(area * 9); // 9 por metro quadrado
        double valorTotal = totalAzulejos * 12.5;

        System.out.printf("Valor gasto: R$ %.2f\n", valorTotal);

        scanner.close();
    }
}