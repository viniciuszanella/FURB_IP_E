import java.time.LocalDate;
import java.util.Locale;

public class Uni5Exe22 {
    public static void main(String[] args) {
        double salario = 2000.0;
        double taxa = 0.015;
        int ano = 1996;
        int anoAtual = LocalDate.now().getYear();
        while (ano <= anoAtual) {
            salario *= (1 + taxa);
            taxa *= 2;
            ano++;
        }
        Locale.setDefault(Locale.US);
        System.out.printf("Salário inicial (1995): R$%.2f%n", 2000.0);
        System.out.printf("Ano calculado: %d%n", anoAtual);
        System.out.printf("Salário atual: R$%.2f%n", salario);
    }
}
