import java.util.Scanner;

public class Uni5Exe24 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe o limite diário de pesca (em kg): ");
        double limiteKg = scanner.nextDouble();
        double limiteGramas = limiteKg * 1000;
        double totalGramas = 0;
        char continuar;
        do {
            System.out.print("Informe o peso do peixe (em gramas): ");
            double pesoPeixe = scanner.nextDouble();
            totalGramas += pesoPeixe;
            System.out.printf("Peso total acumulado: %.2f gramas (%.2f kg)\n", totalGramas, totalGramas / 1000);
            if (totalGramas > limiteGramas) {
                System.out.println("\n Limite diário de pesca excedido!");
                break;
            }
            System.out.print("Deseja informar o peso de mais um peixe? (s/n): ");
            continuar = scanner.next().toLowerCase().charAt(0);
        } while (continuar == 's');
        if (totalGramas <= limiteGramas) {
            System.out.printf("\nPeso total final: %.2f gramas (%.2f kg)\n", totalGramas, totalGramas / 1000);
            System.out.println("Limite diário NÃO excedido. Parabéns!");
        }
        scanner.close();
    }
}
