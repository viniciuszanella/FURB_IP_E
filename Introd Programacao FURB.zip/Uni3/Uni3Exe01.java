package Uni3;

import java.util.Scanner;

public class Uni3Exe01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a largura do terreno: ");
        double largura = scanner.nextDouble();

        System.out.print("Digite o comprimento do terreno: ");
        double comprimento = scanner.nextDouble();

        double area = largura * comprimento;

        System.out.println("Área do terreno: " + area);

        scanner.close();
    }
}

/**
 * | Largura | Comprimento | Saída esperada (Área) |
 * | ------- | ----------- | --------------------- |
 * | 3       | 6           | 18                    |
 * | 2       | 18          | 36                    |
 * | 4.5     | 10          | 45.0                  |
 */