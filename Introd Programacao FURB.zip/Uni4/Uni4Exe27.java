
package Uni4;

import java.util.Scanner;

public class Uni4Exe27 {
    Scanner scanner = new Scanner(System.in);
    int horaChegada, minChegada, horaSaida, minSaida;
    double preco;

    public Uni4Exe27() {
        coletarDados();
        logica();
        retornarDados();
    }
	private void coletarDados() {
        System.out.print("Hora de chegada: ");
		horaChegada = scanner.nextInt();
		System.out.print("Minuto de chegada: ");
		minChegada = scanner.nextInt();
		System.out.print("Hora de saída: ");
		horaSaida = scanner.nextInt();
		System.out.print("Minuto de saída: ");
		minSaida = scanner.nextInt();
    }
    private void logica() {
        boolean valido = true;
		if (horaChegada < 0 || horaChegada > 23 || minChegada < 0 || minChegada > 59 ||
			horaSaida < 0 || horaSaida > 23 || minSaida < 0 || minSaida > 59) {
			valido = false;
		}
		int minutosChegada = horaChegada * 60 + minChegada;
		int minutosSaida = horaSaida * 60 + minSaida;
		if (minutosSaida < minutosChegada) {
			valido = false;
		}

		if (!valido) {
			System.out.println("Horário inválido.");
			scanner.close();
			return;
		}

		int tempoTotal = minutosSaida - minutosChegada;
		int horas = tempoTotal / 60;
		int minutos = tempoTotal % 60;

		int horasCobradas;
		if (tempoTotal < 30) {
			horasCobradas = 1;
		} else if (minutos <= 29) {
			horasCobradas = horas;
		} else {
			horasCobradas = horas + 1;
		}

		preco = 0.0;
		if (horasCobradas == 1) {
			preco = 5.0;
		} else if (horasCobradas == 2) {
			preco = 10.0;
		} else if (horasCobradas == 3 || horasCobradas == 4) {
			preco = 5.0 * 2 + 7.5 * (horasCobradas - 2);
		} else if (horasCobradas >= 5) {
			preco = 5.0 * 2 + 7.5 * 2 + 10.0 * (horasCobradas - 4);
		}
    }
    private void retornarDados() {
        System.out.printf("Preço cobrado = R$%.2f\n", preco);
    }
    public static void main(String[] args) {
        new Uni4Exe27();
	}
}
