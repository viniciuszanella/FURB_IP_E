import java.util.Scanner;

public class Uni5Exe6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double alturaTotal = 0;
        for (int i = 1; i <= 20; i++) {
            System.out.println("Insira a altura da pessoa " + i + ":");
            alturaTotal += scanner.nextDouble();
        }
        double alturaMedia = alturaTotal / 20;
        System.out.printf("Altura média: %.2f\n", alturaMedia);
        scanner.close();
    }
}
