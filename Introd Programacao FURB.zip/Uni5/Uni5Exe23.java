import java.util.Scanner;

public class Uni5Exe23 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char continuar;
        do {
            System.out.print("Nome do vendedor: ");
            String nome = scanner.next();
            System.out.print("Número de produtos vendidos: ");
            int numProdutos = scanner.nextInt();
            double totalVendas = 0;
            for (int i = 1; i <= numProdutos; i++) {
                System.out.print("Preço unitário do produto " + i + ": R$ ");
                double preco = scanner.nextDouble();
                System.out.print("Quantidade vendida do produto " + i + ": ");
                int quantidade = scanner.nextInt();
                totalVendas += preco * quantidade;
            }
            double salario = totalVendas * 0.30;
            System.out.println("\n--- RELATÓRIO DO VENDEDOR ---");
            System.out.println("Nome: " + nome);
            System.out.printf("Total de vendas: R$%.2f\n", totalVendas);
            System.out.printf("Salário (30%% de comissão): R$%.2f\n", salario);
            System.out.println("-----------------------------\n");
            System.out.print("Deseja digitar os dados de mais um vendedor? (s/n): ");
            continuar = scanner.next().toLowerCase().charAt(0);
        } while (continuar == 's');
        System.out.println("\nEncerrando o programa...");
        scanner.close();
    }
}
