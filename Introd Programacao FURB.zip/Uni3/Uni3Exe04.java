package Uni3;

import java.util.Scanner;

public class Uni3Exe04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a primeira nota: ");
        double nota1 = scanner.nextDouble();

        System.out.print("Digite a segunda nota: ");
        double nota2 = scanner.nextDouble();

        System.out.print("Digite a terceira nota: ");
        double nota3 = scanner.nextDouble();

        double media = (nota1 * 5 + nota2 * 3 + nota3 * 2) / 10;

        System.out.println("Média ponderada: " + String.format("%.2f", media));

        scanner.close();
    }
}

/**
 * | Nota 1 | Nota 2 | Nota 3 | Média Esperada |
 * |--------|--------|--------|----------------|
 * | 9      | 6      | 8      | 7.90           |
 * | 4      | 8      | 6      | 5.60           |
 * | 10     | 10     | 10     | 10.00          |
 */
