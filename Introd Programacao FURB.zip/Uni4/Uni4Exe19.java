package Uni4;

import java.util.Scanner;

public class Uni4Exe19 {
    Scanner scanner = new Scanner(System.in);
    int x, y;

    public Uni4Exe19() {
        x = scanner.nextInt();
        y = scanner.nextInt();

        if (x == 0 && y == 0) {
            System.out.println("Quadrante 0");
            return;
        }

        if (x > 0 && y > 0) {
             System.out.println("Quadrante 1");
            return;
        }

        if (x > 0 && y < 0) {
            System.out.println("Quadrante 2");
            return;
        }

        if (x < 0 && y < 0) {
            System.out.println("Quadrante 3");
            return;
        }

        System.out.println("Quadrante 4");
        return;
    }

    public static void main(String[] args) {
        new Uni4Exe19();
    }
}
