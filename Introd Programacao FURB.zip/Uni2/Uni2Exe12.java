package Uni2;
import java.util.Scanner;

public class Uni2Exe12 {
    
    /**
     * Calcule a distância entre dois pontos (x1, y1) e (x2, y2).
     * 
     * Teste de Mesa
     * Entrada: (1.0, 7.0), (5.0, 9.0)
     * Processamento: √[(5−1)² + (9−7)²] = √[16 + 4] = √20
     * Saida: 4.4721
     * 
     * Entrada: (0, 0), (3, 4)
     * Processamento: √(9 + 16) = √25
     * Saida: 5.0000
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("x1: ");
        double x1 = scanner.nextDouble();

        System.out.print("y1: ");
        double y1 = scanner.nextDouble();

        System.out.print("x2: ");
        double x2 = scanner.nextDouble();

        System.out.print("y2: ");
        double y2 = scanner.nextDouble();

        double distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        System.out.printf("Distância: %.4f\n", distancia);

        scanner.close();
    }
    
}