package Uni4;

import java.util.Scanner;

public class Uni4Exe11 {
    Scanner scanner = new Scanner(System.in);
    int idade1, idade2, idade3;

    public Uni4Exe11() {
        coletarDados();
        retornarDados();
    }

    private void coletarDados() {
        idade1 = scanner.nextInt();
        idade2 = scanner.nextInt();
        idade3 = scanner.nextInt();
    }

    private void retornarDados() {
        if (idade1 == idade2 && idade1 == idade3) {
            System.out.println("TRIGÊMEOS");
            return;
        }

        if (idade1 == idade2 && idade1 != idade3 || idade2 == idade3 && idade2 != idade1) {
            System.out.println("GÊMEOS");
            return;
        }

        System.out.println("APENAS IRMÃOS");
        return;
    }

    public static void main(String[] args) {
        new Uni4Exe11();
    }
}
