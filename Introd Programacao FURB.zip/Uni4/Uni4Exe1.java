package Uni4;

import java.util.Scanner;

class Uni4Exe1 {
    Scanner scanner = new Scanner(System.in);
    double horasMes;
    double horasValor;
    double salarioTotal;

    public Uni4Exe1() {
        coletarDados();
        logica();
        retornarDados();
        scanner.close();
    }

    public void coletarDados() {
        System.out.print("Entre com as horas trabalhadas no mês: ");
        horasMes = scanner.nextDouble();
        System.out.print("Entre com o valor pago por hora: ");
        horasValor = scanner.nextDouble();
    }

    public void logica() {
        salarioTotal = horasMes * horasValor;
        if (horasMes > 160) {
            double salarioExtra = ( horasMes - 160 ) * ( horasValor / 2 );
            salarioTotal += salarioExtra;
        }
    }

    public void retornarDados() {
        System.out.println("O salário total é: " + salarioTotal);
    }

    public static void main(String[] args) {
        new Uni4Exe1();
    }
}