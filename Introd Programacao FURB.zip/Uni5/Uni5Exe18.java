import java.util.Scanner;

public class Uni5Exe18 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int canal;
        int pessoas;
        int totalPessoas = 0;
        int pessoasCanal4 = 0;
        int pessoasCanal5 = 0;
        int pessoasCanal9 = 0;
        int pessoasCanal12 = 0;
        while (true) {
            System.out.print("Canal: ");
            canal = scanner.nextInt();
            if (canal == 0)
                break;
            System.out.print("Pessoas assistindo: ");
            pessoas = scanner.nextInt();
            if (pessoas < 0) {
                System.out.println("Número inválido de pessoas. Tente novamente.");
                continue;
            }
            switch (canal) {
                case 4:
                    pessoasCanal4 += pessoas;
                    break;
                case 5:
                    pessoasCanal5 += pessoas;
                    break;
                case 9:
                    pessoasCanal9 += pessoas;
                    break;
                case 12:
                    pessoasCanal12 += pessoas;
                    break;
                default:
                    System.out.println("Canal inválido! Use apenas 4, 5, 9 ou 12.");
                    continue; // ignora canais inválidos
            }
            totalPessoas += pessoas;
        }
        if (totalPessoas > 0) {
            double perc4 = (pessoasCanal4 * 100.0) / totalPessoas;
            double perc5 = (pessoasCanal5 * 100.0) / totalPessoas;
            double perc9 = (pessoasCanal9 * 100.0) / totalPessoas;
            double perc12 = (pessoasCanal12 * 100.0) / totalPessoas;
            System.out.printf("Percentual de audiência do canal 4: %.0f%%\n", perc4);
            System.out.printf("Percentual de audiência do canal 5: %.0f%%\n", perc5);
            System.out.printf("Percentual de audiência do canal 9: %.0f%%\n", perc9);
            System.out.printf("Percentual de audiência do canal 12: %.0f%%\n", perc12);
        } else {
            System.out.println("Nenhuma audiência registrada.");
        }
        scanner.close();
    }
}
