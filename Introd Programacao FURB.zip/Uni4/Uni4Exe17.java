package Uni4;
import java.util.Scanner;

public class Uni4Exe17 {
    Scanner scanner = new Scanner(System.in);
    double rendaAnual, desconto, rendaLiquida, valorImposto, imposto;
    int dependentes;

    public Uni4Exe17() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.print("Informe a renda anual: R$ ");
        rendaAnual = scanner.nextDouble();
        System.out.print("Informe o número de dependentes: ");
        dependentes = scanner.nextInt();
    }

    private void logica() {
        double desconto = rendaAnual * (dependentes * 0.02);
        double rendaLiquida = rendaAnual - desconto;

        valorImposto = 0.0;
        imposto = 0.0;
        if (rendaLiquida <= 2000.0) {
            valorImposto = 0.0;
        } else if (rendaLiquida <= 5000.0) {
            imposto = 0.05;
            valorImposto = rendaLiquida * 0.05;
        } else if (rendaLiquida <= 10000.0) {
            imposto = 0.10;
            valorImposto = rendaLiquida * 0.10;
        } else {
            imposto = 0.15;
            valorImposto = rendaLiquida * 0.15;
        }
    }

    private void retornarDados() {
        System.out.println("O imposto é de " + imposto * 100 + "%: R$ " + valorImposto);
    }

    public static void main(String[] args) {
        new Uni4Exe17();
    }
}
