package Uni4;

import java.util.Scanner;

public class Uni4Exe10 {
    Scanner scanner = new Scanner(System.in);
    float idadeMarquinhos, idadeZezinho, idadeLuluzinha;

    public Uni4Exe10() {
        coletarDados();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Digite a idade do Marquinhos: ");
        idadeMarquinhos = scanner.nextFloat();
        System.out.println("Digite a idade do Zezinho: ");
        idadeZezinho = scanner.nextFloat();
        System.out.println("Digite a idade da Luluzinha: ");
        idadeLuluzinha = scanner.nextFloat();
    }

    private void retornarDados() {
        if (idadeMarquinhos < idadeZezinho && idadeMarquinhos < idadeLuluzinha) {
            System.out.println("O Marquinhos é o caçula");
        } else if (idadeZezinho < idadeMarquinhos && idadeZezinho < idadeLuluzinha) {
            System.out.println("O Zezinho é o caçula");
        } else {
            System.out.println("A Luluzinha é a caçula");
        }
    }

    public static void main(String[] args) {
        new Uni4Exe10();
    }
}
