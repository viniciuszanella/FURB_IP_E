package Uni2;
import java.util.Scanner;

public class Uni2Exe19 {

    /**
     * A = B, C = D. Leia B, C, D. Calcule A.
     * 
     * Teste de Mesa
     * Entrada: B = 10, C = 20, D = 20
     * A = B = 10
     * Saida: 10
     * 
     * Entrada: B = 5, C = 15, D = 15
     * Saida: 5
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("B: ");
        int B = scanner.nextInt();

        System.out.print("C: ");
        int C = scanner.nextInt();

        System.out.print("D: ");
        int D = scanner.nextInt();

        int A = B;
        C = D;

        System.out.println("A = " + A);
        System.out.println("C = " + C);

        scanner.close();
    }
}