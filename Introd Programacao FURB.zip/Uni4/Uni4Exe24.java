
package Uni4;

import java.util.Scanner;

public class Uni4Exe24 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcao = sc.nextInt();
        switch (opcao) {
            case 1:
                System.out.println("Domingo");
                for (int i = 0; i < 6; i++) {
                    System.out.println("Domingo");
                }
                break;
    }
}
}
