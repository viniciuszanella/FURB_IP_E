package Uni2;
import java.util.Scanner;

public class Uni2Exe04 {
    /**
     * Leia dois valores de ponto flutuante e calcule a média ponderada (peso A: 3.5, peso B: 7.5).
     * 
     * Teste de Mesa
     * Entrada: 5.0, 7.1
     * Processamento: ((5.0 * 3.5) + (7.1 * 7.5)) / 11 = (17.5 + 53.25) / 11
     * Saida: 6.212
     * 
     * Entrada: 0.0, 7.5
     * Processamento: ((0.0 * 3.5) + (7.5 * 7.5)) / 11 = (0 + 56.25) / 11
     * Saida: 5.1136
     * 
     * Entrada: 10.0, 10.0
     * Processamento: ((10 * 3.5) + (10 * 7.5)) / 11 = (35 + 75) / 11
     * Saida: 10.0
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Insira o primeiro valor de ponto flutuante: ");
        double valor1 = scanner.nextDouble() * 3.5;
        
        System.out.print("Insira o segundo valor de ponto flutuante: ");
        double valor2 = scanner.nextDouble() * 7.5;

        System.out.print("A média é: " + (valor1 + valor2) / 11);

        scanner.close();
    }
}