package Uni4;

import java.util.Scanner;

public class Uni4Exe22 {
    Scanner scanner = new Scanner(System.in);
    int opcao;

    public Uni4Exe22() {
        coletarDados();
        retornarDados();
    }

    private void coletarDados() {
        opcao = scanner.nextInt();
    }

    private void retornarDados() {
        if (opcao == 1) {
            System.out.println("Bacharel em Ciência da Computação");
        } else if (opcao == 2) {
            System.out.println("Licenciado em Computação");
        } else if (opcao == 3) {
            System.out.println("Bacharel em Sistemas de Informação");
        }
    }

 public static void main(String[] args) {
        new Uni4Exe22();
    }
}
