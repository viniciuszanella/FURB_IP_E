import java.util.Scanner;

public class Uni5Exe33 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int voto;
        int cand1 = 0, cand2 = 0, cand3 = 0, cand4 = 0;
        int nulos = 0, brancos = 0;
        int totalVotos = 0;
        do {
            System.out.print("\nDigite seu voto (1-4=candidatos, 5=nulo, 6=branco, 0=encerra): ");
            voto = teclado.nextInt();
            switch (voto) {
                case 0:
                    break;
                case 1:
                    cand1++;
                    totalVotos++;
                    break;
                case 2:
                    cand2++;
                    totalVotos++;
                    break;
                case 3:
                    cand3++;
                    totalVotos++;
                    break;
                case 4:
                    cand4++;
                    totalVotos++;
                    break;
                case 5:
                    nulos++;
                    totalVotos++;
                    break;
                case 6:
                    brancos++;
                    totalVotos++;
                    break;
                default:
                    System.out.println("Opção incorreta!");
                    break;
            }
        } while (voto != 0);
        System.out.println("\n--- RESULTADO DA ELEIÇÃO ---");
        System.out.println("Candidato 1: " + cand1 + " votos");
        System.out.println("Candidato 2: " + cand2 + " votos");
        System.out.println("Candidato 3: " + cand3 + " votos");
        System.out.println("Candidato 4: " + cand4 + " votos");
        System.out.println("Votos nulos: " + nulos);
        System.out.println("Votos em branco: " + brancos);
        if (totalVotos > 0) {
            double percNulos = (nulos * 100.0) / totalVotos;
            double percBrancos = (brancos * 100.0) / totalVotos;
            System.out.printf("Percentual nulos: %.2f%%\n", percNulos);
            System.out.printf("Percentual brancos: %.2f%%\n", percBrancos);
        } else {
            System.out.println("Nenhum voto registrado.");
        }
        teclado.close();
    }
}
