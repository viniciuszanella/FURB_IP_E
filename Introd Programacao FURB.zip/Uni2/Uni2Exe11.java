package Uni2;
import java.util.Scanner;

public class Uni2Exe11 {

    /**
     * Leia três valores A, B e C. Calcule e mostre áreas.
     * 
     * Teste de Mesa
     * Entrada: 3.0, 4.0, 5.2
     * a) (3.0 * 5.2) / 2 = 7.8
     * b) π * 5.2² = 3.14159 * 27.04 = 84.949
     * c) ((3.0 + 4.0) * 5.2) / 2 = 18.2
     * d) 4.0² = 16.0
     * e) 3.0 * 4.0 = 12.0
     * 
     * Saida:
     * Triângulo: 7.80
     * Círculo: 84.95
     * Trapézio: 18.20
     * Quadrado: 16.00
     * Retângulo: 12.00
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("A: ");
        double A = scanner.nextDouble();

        System.out.print("B: ");
        double B = scanner.nextDouble();

        System.out.print("C: ");
        double C = scanner.nextDouble();

        double triangulo = (A * C) / 2;
        double circulo = 3.14159 * C * C;
        double trapezio = ((A + B) * C) / 2;
        double quadrado = B * B;
        double retangulo = A * B;

        System.out.printf("TRIANGULO: %.3f\n", triangulo);
        System.out.printf("CIRCULO: %.3f\n", circulo);
        System.out.printf("TRAPEZIO: %.3f\n", trapezio);
        System.out.printf("QUADRADO: %.3f\n", quadrado);
        System.out.printf("RETANGULO: %.3f\n", retangulo);

        scanner.close();
    }
    
}