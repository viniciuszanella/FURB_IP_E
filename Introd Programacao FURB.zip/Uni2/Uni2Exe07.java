package Uni2;
import java.util.Scanner;

public class Uni2Exe07 {
    /**
     * Leia nome, salário fixo e total de vendas. Vendedor ganha 15% de comissão.
     * 
     * Teste de Mesa
     * Entrada: Ana, 500.00, 1230.30
     * Processamento: 500 + (1230.30 * 0.15) = 500 + 184.545
     * Saida: Total: 684.55
     * 
     * Entrada: Bruno, 700.00, 500.00
     * Processamento: 700 + (500 * 0.15) = 700 + 75
     * Saida: Total: 775.00
     * 
     * Entrada: Carlos, 1200.00, 0
     * Processamento: 1200 + (0 * 0.15) = 1200
     * Saida: Total: 1200.00
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nome do vendedor: ");
        String vendedorNome = scanner.nextLine();

        System.out.print("Insira o salário fixo do vendedor: ");
        double salarioFixo = scanner.nextDouble();

        System.out.print("Vendas efetuadas no mês ($): ");
        double vendasMes = scanner.nextDouble();

        double salarioTotal = salarioFixo + (vendasMes * 0.15);
        String salarioTotalFormatado = String.format("%.2f", salarioTotal);

        System.out.print("O vendedor " + vendedorNome + " vai ganhar " + salarioTotalFormatado + " nesse mês");
        scanner.close();
    }
}
