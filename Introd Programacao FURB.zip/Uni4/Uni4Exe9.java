package Uni4;

import java.util.Scanner;

public class Uni4Exe9 {
    Scanner scanner = new Scanner(System.in);
    float numero1, numero2, resto;

    public Uni4Exe9() {
        coletarDados();
        logica();
        retornarDados();
    }

    private void coletarDados() {
        System.out.println("Digite o primeiro numero: ");
        numero1 = scanner.nextFloat();
        System.out.println("Digite o segundo numero: ");
        numero2 = scanner.nextFloat();
    }

    private void logica() {
        resto = numero1 % numero2;
    }

    private void retornarDados() {
        if (resto == 0) {
            System.out.println("Os valores são multiplos");
        } else {
            System.out.println("Os valores não são multiplos");
        }
    }

    public static void main(String[] args) {
        new Uni4Exe9();
    }
}
